# Eyebound (Paper 1.20.4, Java 17+)

## Build
    mvn clean package
Jar ends up in `target/Eyebound-1.0.0.jar`. Copy it into `server/plugins/`.

## Run the server
1. Download Paper 1.20.4 (https://papermc.io/downloads/paper), save as `server/paper.jar`.
2. Run `server/start.sh` (or `start.bat`). First run creates `eula.txt`; set `eula=true`, run again.
3. Host `EyesPack.zip` at a direct-download link, then either
   - put the link in `plugins/Eyebound/config.yml` -> `resource-pack.url`, or
   - put it in `server.properties` -> `resource-pack=`.

## Controls
- Eye Wheel item (ender eye, given on join, or `/eyes wheel`)
  - Right-click: open the GUI wheel. Left-click an eye = slot 1, right-click an eye = slot 2.
  - Left-click with the item: switch the active slot.
- `F` = ability 1, `Shift+F` = ability 2 of the active eye.
- Action bar above the xp bar shows `0 - 0` (empty) or the pixel-art eye icons; the active slot is brighter.
- Commands: `/eyes`, `/eyes wheel`, `/eyes equip <1|2> <cloud|nature|fire|void|laser>`, `/eyes use [secondary]`, `/eyes reload`.

## Eyes
| Eye | F | Shift+F | Passive |
|---|---|---|---|
| Cloud | Cloud under feet, fly 15s | - | No fall damage |
| Nature | Vines, 2 hp x stacks per second inside | - | Hero of the Village (infinite) |
| Fire | Ignite enemies within 8 blocks for 16s (ignores fire resistance + water) | Fire form 15s, Strength II | Fire Resistance |
| Void | Void puddle 5s: hidden, Speed IV, silent | - | - |
| Laser | Red beam 5s, 3 hearts per second of contact | - | Resistance I |

Rules: max Protection 3 / Sharpness 2 (enchanting table, anvil, pickup, join, inventory close) and Strength II blocked from potions/beacons. The Fire form's Strength II is exempt (toggle in config).

## Known limits
- Mining sounds: Void Eye silences movement/footsteps (`setSilent`), but vanilla block-break sounds are sent as separate packets; cancelling them needs ProtocolLib.
- Resource packs cannot add new particle types, so the pack replaces the flame and soul-fire-flame particle textures and adds pixel-art sprites (cloud, vines, void puddle, laser orb) shown via item displays.
- Written for 1.20.4 API names (STRENGTH = INCREASE_DAMAGE, etc.). For 1.20.5+ rename those effect constants.
