@echo off
rem Put the Paper 1.20.4 jar next to this file and name it paper.jar
cd /d "%~dp0"
if not exist paper.jar (
  echo Download Paper 1.20.4 from https://papermc.io/downloads/paper and save it here as paper.jar
  pause
  exit /b
)
java -Xms2G -Xmx4G -jar paper.jar --nogui
pause
