package dev.eyes;

import net.kyori.adventure.text.format.NamedTextColor;

public enum Eye {
    CLOUD("Cloud Eye", NamedTextColor.WHITE, '\uE001', 1001, "Cloud Walk", null, "No fall damage"),
    NATURE("Nature Eye", NamedTextColor.GREEN, '\uE002', 1002, "Vine Grasp", null, "Hero of the Village (infinite)"),
    FIRE("Fire Eye", NamedTextColor.GOLD, '\uE003', 1003, "Inferno Pulse", "Fire Form", "Fire Resistance"),
    VOID("Void Eye", NamedTextColor.DARK_PURPLE, '\uE004', 1004, "Void Puddle", null, "Silent steps while hidden"),
    LASER("Laser Eye", NamedTextColor.RED, '\uE005', 1005, "Red Beam", null, "Resistance I");

    public final String display;
    public final NamedTextColor color;
    public final char glyph;
    public final int cmd;
    public final String primary, secondary, passive;

    Eye(String display, NamedTextColor color, char glyph, int cmd, String primary, String secondary, String passive) {
        this.display = display; this.color = color; this.glyph = glyph; this.cmd = cmd;
        this.primary = primary; this.secondary = secondary; this.passive = passive;
    }

    public static Eye parse(String s) {
        if (s == null) return null;
        for (Eye e : values()) if (e.name().equalsIgnoreCase(s) || e.name().equalsIgnoreCase(s.replace("_eye", ""))) return e;
        return null;
    }
}
