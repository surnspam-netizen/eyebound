package dev.eyes;

import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.ItemStack;

public class EyeListener implements Listener {
    private final EyesPlugin plugin;

    public EyeListener(EyesPlugin plugin) { this.plugin = plugin; }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        String url = plugin.getConfig().getString("resource-pack.url", "");
        if (url != null && !url.isBlank()) p.setResourcePack(url);
        if (plugin.getConfig().getBoolean("give-wheel-on-join", true)) {
            boolean has = false;
            for (ItemStack it : p.getInventory().getContents()) if (EyesPlugin.isWheel(it)) { has = true; break; }
            if (!has) p.getInventory().addItem(EyesPlugin.wheel());
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) { plugin.manager().save(); }

    /** F = ability 1, Shift+F = ability 2 of the active eye. */
    @EventHandler
    public void onSwap(PlayerSwapHandItemsEvent e) {
        if (!plugin.getConfig().getBoolean("use-f-key", true)) return;
        Player p = e.getPlayer();
        if (plugin.manager().activeEye(p) == null) return;
        e.setCancelled(true);
        plugin.abilities().use(p, p.isSneaking());
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() == null || e.getHand() != org.bukkit.inventory.EquipmentSlot.HAND) return;
        if (!EyesPlugin.isWheel(e.getItem())) return;
        e.setUseInteractedBlock(Event.Result.DENY);
        e.setUseItemInHand(Event.Result.DENY);
        Action a = e.getAction();
        if (a == Action.RIGHT_CLICK_AIR || a == Action.RIGHT_CLICK_BLOCK) {
            plugin.gui().open(e.getPlayer());
        } else if (a == Action.LEFT_CLICK_AIR || a == Action.LEFT_CLICK_BLOCK) {
            plugin.manager().swapActive(e.getPlayer());
        }
    }

    /** Cloud Eye passive: no fall damage. */
    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        if (e.getCause() == EntityDamageEvent.DamageCause.FALL && e.getEntity() instanceof Player p
                && plugin.manager().has(p, Eye.CLOUD)) e.setCancelled(true);
    }

    /** Mobs can't target players hidden by the Void Eye. */
    @EventHandler
    public void onTarget(EntityTargetEvent e) {
        if (e.getTarget() instanceof Player p && plugin.abilities().isHidden(p.getUniqueId())) e.setCancelled(true);
    }
}
